# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt

# Read in the data file
df = pd.read_csv("weather_data_graz_04_15_1994_2024.csv")

# Plot temperature
fig_temp, ax1 = plt.subplots(figsize=(12, 6))
ax1.plot(df['Year'], df['Temperature (°C)'], color='tab:red', marker='o', label='Temperature (°C)')
ax1.set_xlabel('Year')
ax1.set_ylabel('Temperature (°C)', color='tab:red')
ax1.tick_params(axis='y', labelcolor='tab:red')
ax1.legend(loc='upper left')
ax1.set_title('Temperature in Graz on April 15 (1994-2023)')
fig_temp.savefig('temperature_plot.png')

# Plot relative humidity
fig_humidity, ax2 = plt.subplots(figsize=(12, 6))
ax2.plot(df['Year'], df['Relative Humidity (%)'], color='tab:blue', marker='o', label='Relative Humidity (%)')
ax2.set_xlabel('Year')
ax2.set_ylabel('Relative Humidity (%)', color='tab:blue')
ax2.tick_params(axis='y', labelcolor='tab:blue')
ax2.legend(loc='upper left')
ax2.set_title('Relative Humidity in Graz on April 15 (1994-2023)')
fig_humidity.savefig('humidity_plot.png')

# Plot precipitation
fig_precipitation, ax3 = plt.subplots(figsize=(12, 6))
ax3.plot(df['Year'], df['Precipitation (mm)'], color='tab:green', marker='o', label='Precipitation (mm)')
ax3.set_xlabel('Year')
ax3.set_ylabel('Precipitation (mm)', color='tab:green')
ax3.tick_params(axis='y', labelcolor='tab:green')
ax3.legend(loc='upper left')
ax3.set_title('Precipitation in Graz on April 15 (1994-2023)')
fig_precipitation.savefig('precipitation_plot.png')

# Show the plots
plt.show()