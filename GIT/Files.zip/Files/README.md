# Graz Climate Project



## Scope


## People involved


## Integrated Features


## Timeline